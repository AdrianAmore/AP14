﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ej1
{
    public partial class Form1 : Form
    {
        List<Socio> listSocios = new List<Socio>();
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblCm.Text = tckBarAltura.Value.ToString() + " cm";
            lblSocios.Text = "Nº de Socios: " + listSocios.Count.ToString();
        }

        private void tckBarAltura_Scroll(object sender, EventArgs e)
        {
            lblCm.Text = tckBarAltura.Value.ToString() + " cm";
        }

        private void btnAlta_Click(object sender, EventArgs e)
        {
            char genero;
            if (rdbHombre.Checked)
            {
                genero = 'H';
            }
            else
            {
                genero = 'M';
            }
            Socio soc = new Socio(txtNombre.Text, nmrUDEdad.Value, genero, double.Parse(txtPeso.Text), tckBarAltura.Value);
            lblNif.Text = "NIF: " + soc.NIF;
            lblEstado.Text = "Estado: " + soc.CalcularIMC();
            listSocios.Add(soc);
            lblSocios.Text = "Nº de Socios: " + listSocios.Count.ToString();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            char genero;
            if (rdbHombre.Checked)
            {
                genero = 'H';
            }
            else
            {
                genero = 'M';
            }
            string mensaje = "Nombre: " + txtNombre.Text + "\t" + lblNif.Text;
            mensaje += "\r\nEdad: " + nmrUDEdad.Value.ToString() + "\t\tSexo: " + genero;
            mensaje += "\r\nPeso: " + txtPeso.Text + "\tAltura:" + lblCm.Text;
            mensaje += "\r\n" + lblNif.Text;
            mensaje += "\r\n" + lblEstado.Text;
            MessageBox.Show(mensaje);
        }
    }
}
